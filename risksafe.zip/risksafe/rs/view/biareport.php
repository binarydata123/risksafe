<?php

include_once("../controller/auth.php");
include_once("../config.php");
include_once('../model/bia.php');

/** Include PHPExcel */
require_once dirname(__FILE__) . '/../Classes/PHPExcel.php';

$startDate = "";
$endDate ="";

$bia = new bia();
if (isset($_POST["action"]) && $_POST["action"]=="downloadxls") {
	
	//$startDate = $_REQUEST['startDate'];
	//$endDate = $_REQUEST['endDate'];
	
	$objPHPExcel = new PHPExcel();
	$objPHPExcel->getProperties()->setCreator("RiskSafe")
								 ->setLastModifiedBy("RiskSafe")
								 ->setTitle("Business Impact Analysis  Report")
								 ->setSubject("BIA Report")
								 ->setDescription("")
								 ->setKeywords("")
								 ->setCategory("");
	$row = 1;						 
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$row, 'Risk Safe')
	            ->setCellValue('B'.$row, 'Business Impact Analysis Report');	            								 
	
	$row = 2;		
	$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$row, 'Critical Business Activity')
	            ->setCellValue('B'.$row, 'Description')
	            ->setCellValue('C'.$row, 'Priority')
	            ->setCellValue('D'.$row, 'Impact of Loss')
	            ->setCellValue('E'.$row, 'Recovery Time Objective')
				->setCellValue('F'.$row, 'Preventative/Recovery Actions')
				->setCellValue('G'.$row, 'Resource Requirements');				
	$row++;		
	
	$list = $bia->listBIAForReport();
	foreach ($list as $item) {
		$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$row, $item['bia_activity'])
	            ->setCellValue('B'.$row, $item['bia_descript'])
	            ->setCellValue('C'.$row, $item['bia_priority'])
	            ->setCellValue('D'.$row, $item['bia_impact'])
	            ->setCellValue('E'.$row, $item['bia_time'])
				->setCellValue('F'.$row, $item['bia_action'])
				->setCellValue('G'.$row, $item['bia_resource']);
		$row++;	
	}

	$objPHPExcel->getActiveSheet()->getStyle('A1:G1')->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->getStyle('A2:G2')->getFont()->setBold(true);
	
	$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(40);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(40);
	$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
	$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(60);
	$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(60);    

	$objPHPExcel->setActiveSheetIndex(0);
	$objPHPExcel->getActiveSheet()->setTitle('BIA Report');

	// Redirect output to a client’s web browser (Excel2007)
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	header('Content-Disposition: attachment;filename="BIA Report.xlsx"');
	header('Cache-Control: max-age=0');
	// If you're serving to IE 9, then the following may be needed
	header('Cache-Control: max-age=1');
	
	// If you're serving to IE over SSL, then the following may be needed
	header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	header ('Pragma: public'); // HTTP/1.0
	
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save('php://output');
	exit;
	
} else {
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once("header.php");?>
</head>
<body>
<!-- header -->
<div id="top-nav" class="navbar navbar-inverse navbar-static-top" style="background-color:#09F;border:0;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="main.php" style="font-weight:900;color:#fff;"><?php echo APP_TITLE;?></a> </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"> <a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#" style="font-weight:900;color:#fff;"><i class="glyphicon glyphicon-user"></i> Account <span class="caret"></span></a>
          <ul id="g-account-menu" class="dropdown-menu" role="menu">
			<?php include_once("menu_top.php");?>
          </ul>
        </li>
      </ul>
    </div>
  </div>
  <!-- /container --> 
</div>
<!-- /Header --> 

<!-- Main -->
<div class="container-fluid">
<div class="row">
  <div class="col-lg-3 col-sm-12"> 
    <!-- Left column --> 
	<?php include_once("menu.php");?>
  <!-- /col-3 -->
  </div>
  <div class="col-lg-9 col-md-12">
    <h1 class="page-header">Business Impact Analysis Report</h1>
    
  		<div class="">
  	
		  	<div class="alert <?php if (isset($msgClass)) echo $msgClass;?>" id="notify" <?php if (!isset($msg)) { ?>style="display: none;"<?php } ?>>
		    	<?php if (isset($msg)) echo $msg;?>
		  	</div>
		  	
		    <div class="panel panel-default">
		      <div class="panel-body">
		        <form role="form" id="form" action="../view/biareport.php" method="post">
		        	<input type="hidden" name="action" value="downloadxls" />
		        	<!--
		         <div class="form-group">
		            <label>Start Date</label>
		            <input value="<?php echo $startDate;?>" name="startDate" type="text" class="form-control datepicker" placeholder="Enter start date" required>        
		          </div>
		           <div class="form-group">
		            <label>End Date</label>
		            <input value="<?php  echo $endDate; ?>" name="endDate" type="text" class="form-control datepicker" placeholder="Enter end date" required>
		        
		          </div>-->
		          <div class="form-group">
		          	  <button type="submit" class="btn btn-md btn-info" id="btn_save">Download Excel</button>			                  			          			        
		          </div>
		        </form>
		      </div>
		    </div>
		  </div>
  </div>
  <!--/col-span-9--> 
</div>  
</div>

<!-- /Main -->

<?php include_once("footer.php");?>
<script>
$(document).ready(function(e) {
 	$( ".datepicker" ).datepicker(); 	
}); 
  </script>
</script>
</body>
</html>