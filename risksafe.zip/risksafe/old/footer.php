		<div id="footer">
			<div class="responsive">
				<div id="fleft">Copyright&copy; RiskSafe 2015</div>
				<div id="fright">
					<a href="#">Privacy Policy</a> 
					<a href="#">Terms and Conditions</a>
					<a href="#">Help Centre</a>
					<a href="tel:+61390051277">+61 3 9005 1277</a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</body>
</html>