<?php include_once("navbar_loggedout.php"); ?>
<div id="bgsection">
	<div class="responsive">
		<img src="img/logo.png" alt="Logo" width="255" height="255">
		<div id="headlines">
			<h1>This is a headline</h1>
			<h3>This is some description. Dummy text. This is some description. Dummy text. </h3>
		</div>
		<div id="inputholder">
			<a href="signup.php" class="bluebtn noborder">Try RiskSafe &raquo;</a>
		</div>
	</div>
</div>
<div id="revsection">
	<div class="responsive">
		<table>
			<tr>
				<td>
					<img src="img/testimonial.png">
					<h4>John Doe</h4>
					<p>"This is the testimonial text."</p>
					
				</td>
				<td>
					<img src="img/testimonial.png">
					<h4>John Doe</h4>
					<p>"This is the testimonial text."</p>
				</td>
				<td>
					<img src="img/testimonial.png">
					<h4>John Doe</h4>
					<p>"This is the testimonial text."</p>
				</td>
			</tr>
		</table>
	</div>
</div>